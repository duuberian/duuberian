#!/usr/bin/env bash
# Builds ELAudio Mic (a renamed BlackHole) into ../build/ELAudioMic.driver
set -euo pipefail
cd "$(dirname "$0")"
OUT=../build/ELAudioMic.driver
rm -rf "$OUT"
mkdir -p "$OUT/Contents/MacOS" "$OUT/Contents/Resources"
clang -arch arm64 -arch x86_64 -mmacosx-version-min=11.0 -O2 -bundle -Wno-everything \
  -DDEBUG=0 \
  -DkDriver_Name='"ELAudioMic"' \
  -DkPlugIn_BundleID='"com.duuberian.ELAudio.VirtualMic"' \
  -DkPlugIn_Icon='"ELAudioMic.icns"' \
  -DkHas_Driver_Name_Format=false \
  -DkDevice_Name='"ELAudio Mic"' \
  -DkDevice2_Name='"ELAudio Mic Mirror"' \
  -DkManufacturer_Name='"EL (built on BlackHole by Existential Audio)"' \
  -DkNumber_Of_Channels=2 \
  -framework CoreAudio -framework CoreFoundation -framework Accelerate \
  -o "$OUT/Contents/MacOS/ELAudioMic" BlackHole.c
cp Info.plist "$OUT/Contents/Info.plist"
cp LICENSE-BlackHole-GPL-3.0.txt "$OUT/Contents/Resources/"
codesign --force --sign - "$OUT"
echo "Built $OUT"
