# ELAudio Mic

A virtual audio device ("ELAudio Mic") that call apps can pick as a microphone. In call mode
ELAudio plays the changed voice into it.

It is [BlackHole](https://github.com/ExistentialAudio/BlackHole) by Existential Audio, built unmodified
from `BlackHole.c` with its documented renaming constants (`build.sh`). BlackHole is licensed under the
GNU GPL v3.0 (`LICENSE-BlackHole-GPL-3.0.txt`); its complete source is this folder. The driver is a
separate program installed into `/Library/Audio/Plug-Ins/HAL`, not linked into the app.
